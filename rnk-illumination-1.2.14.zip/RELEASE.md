# Release Notes

## v1.2.14
- Restructured language support for a new business model.