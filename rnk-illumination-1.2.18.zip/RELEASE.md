# Release Notes

## v1.2.18
- Verified compatibility with Foundry VTT v13.
- Bumped version for release.

## v1.2.14
- Restructured language support for a new business model.